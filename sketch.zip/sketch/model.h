#ifndef MODEL_H
#define MODEL_H

float predict(float x);

#endif  // MODEL_H
